CREATE VIEW s AS
  SELECT
    `initdb`.`developers_projects`.`idProjects` AS `idProjects`,
    sum(`initdb`.`developers`.`salary`)         AS `res`
  FROM (`initdb`.`developers_projects`
    JOIN `initdb`.`developers`
      ON ((`initdb`.`developers_projects`.`idDevelopers` = `initdb`.`developers`.`idDevelopers`)))
  GROUP BY `initdb`.`developers_projects`.`idProjects`;
