CREATE VIEW dd AS
  SELECT
    `initdb`.`developers_projects`.`idDevelopers`          AS `idDevelopers`,
    `initdb`.`developers_projects`.`idDevelopers-projects` AS `idDevelopers-projects`,
    `initdb`.`developers_projects`.`idProjects`            AS `idProjects`,
    `initdb`.`developers`.`name`                           AS `name`,
    `initdb`.`developers`.`salary`                         AS `salary`
  FROM (`initdb`.`developers_projects`
    JOIN `initdb`.`developers`
      ON ((`initdb`.`developers_projects`.`idDevelopers` = `initdb`.`developers`.`idDevelopers`)))
  GROUP BY `initdb`.`developers_projects`.`idProjects`;
